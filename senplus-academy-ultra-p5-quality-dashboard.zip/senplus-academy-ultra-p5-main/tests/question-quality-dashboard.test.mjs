import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("..", import.meta.url));

test("admin quality dashboard supports scanning, filtering and per-question correction", async () => {
  const page = await readFile(`${root}/app/page.tsx`, "utf8");
  const css = await readFile(`${root}/app/globals.css`, "utf8");

  assert.match(page, /admin_question_quality_report/);
  assert.match(page, /admin_update_question_quality/);
  assert.match(page, /執行品質檢查/);
  assert.match(page, /逐題修正/);
  assert.match(page, /問題類型/);
  assert.match(css, /\.quality-editor-modal/);
  assert.match(css, /@media\(max-width:480px\)/);
});

test("quality dashboard database functions are admin-only", async () => {
  const sql = await readFile(`${root}/supabase/admin-question-quality-dashboard-backend.sql`, "utf8");

  assert.match(sql, /is_current_user_admin/);
  assert.match(sql, /只有管理員可以執行題庫品質檢查/);
  assert.match(sql, /只有管理員可以修改題庫/);
  assert.match(sql, /grant execute on function public\.admin_question_quality_report\(\) to authenticated/);
});
